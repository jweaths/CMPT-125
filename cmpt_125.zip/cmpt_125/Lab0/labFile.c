/*
 * Filename: CtoF_v2.c - version 2
 *
 * Description: Read in user provided Celsius temperature
 *              and convert it to a Fahrenheit temperature.
 *              Equation: 0°C × 9/5 + 32 = 32°F
 *
 *
 * Author: AL
 * Date: May 2022
 */

#include <stdio.h>

int main( void ) {
   
    float celTemp = 0.0;  // Celsius temperature
    float fahTemp = 0.0;  // Fahrenheit temperature

    // Prompt user
    printf("Please, enter a temperature in Celsius: ");
    
    // Read in user input
    scanf("%f", &celTemp);

    // Convert celTemp to fahTemp
    fahTemp = celTemp * 9/5 + 32;
    
    // Print result
    printf("%0.1f Celsius => %0.1f Fahrenheit\n", celTemp, fahTemp);  

    return 0;
}
