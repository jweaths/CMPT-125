/*
 * Filename: CtoF_v1.c - version 1
 *
 * Description: Convert a Celsius temperature to a Fahrenheit temperature.
 *              Equation: °C × 9/5 + 32 = °F
 *
 * Author: AL
 * Date: May 2022
 */

#include <stdio.h>

int main( void ) {   
    
    // get a C temperature
    float celTemp = 2.0;  // Celsius Temperature
    float fahTemp = 0.0;  // Fahrenheit Temperature      
    
    // convert it to F
    fahTemp = celTemp * 9/5 + 32;
    
    // share result
    printf( "%.1f Celsius => %.1f Fahrenheit\n", celTemp, fahTemp );
     
    return 0;
}

