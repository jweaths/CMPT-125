/*
*
* Filename: counting.c
*
* Description: 
* counts number of charactersm words and lines
* from stdin until EOF is reached.
*
* Every byte from stdin counts as a character except EOF
* 
* Words are defined as continuous sequences of characters aA-zZ seperated by
* something not in that range
* 
* Lines are defined as a continous sequence of characters separeted by newline characters
*
* Author: JW
* June 17 2022
*
*/

#include <stdio.h>
#define ALPHABET 26

int isLetter(char c) {
	
	int letter = 0;
	
	char lowerArr[ALPHABET] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i',
	 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x',
	 'y', 'z'};
	
	char upperArr[ALPHABET] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
	 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
	 
	 for(int i = 0; i < ALPHABET; i++) {
	 	
	 	if( c == lowerArr[i] || c == '\'') {
	 		
	 		letter = 1;
	 		
	 		}
	 		
	 	}

	 for(int i = 0; i < ALPHABET; i++) {
	 	
	 	if( c == upperArr[i] ) {
	 		
	 		letter = 1;
	 		
	 		}
	 		
	 	}
	 
	return letter;

	}

int main( void )  {

	unsigned long charCount = 0;
	unsigned long wordCount = 0;
	unsigned long lineCount = 0;
	
	int addWord = 0;
	
	int wordValue = 0;
	int isWord = 0;
	

	
	char result;
	
	
	while( (result = getchar()) != EOF ) {

		charCount++; // counts each character iterated
		wordValue = isLetter(result); //determines if char is a letter	
		
		if (result == '\n') {
			
			lineCount++; // counts line
			
			} 
			
		if (wordValue == 1) { // increments isWord if the value is a letter
			
			isWord = 1;		
	
			}
			
		//else if (wordValue == 0) { // adds word if changes to non-letter

		if (wordValue == 0) {
		
			if (isWord == 1 ) {  // ensures we are inside word before it executes
			
				addWord = 1; // increments variable that tells us we have finished a word
				
			}
				
		}
					
		if (isWord == 1 && addWord == 1) { // When are are in a word and then space or \n
		
			addWord = 0;
			isWord = 0;
			wordCount++;
			
			}
		
		}
	
	printf( "%lu %lu %lu\n", charCount, wordCount, lineCount );
	
	return 0;

	}
