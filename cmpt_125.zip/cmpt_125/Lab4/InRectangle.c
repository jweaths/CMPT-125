/*
*
* Filename: InRectangle.c
*
* Description: 
* Contains function that determines whether a point lies inside a rectangle.
* The point and rectangle are both specified using floating point values.
* Define two points and two corners.
* 
*
* Author: JW
* June 17 2022
*
* 
*
*/

#include <stdio.h>
#define POINTS 2
#define CORNERS 4

int InRectangle( float pt[POINTS], float rect[CORNERS] ) {
	
	float X1 = rect[0];
	float Y1 = rect[1];
	float X2 = rect[2];
	float Y2 = rect[3];
	
	float PX = pt[0];
	float PY = pt[1];
	
	int inside = 1;
	
	// formats x values for our function
	
	if (X1 > X2) {
		
		X1 = rect[2];
		X2 = rect[0];
		
		}
	
	// formats y values for our function

	if (Y1 < Y2) {
		
		Y1 = rect[3];
		Y2 = rect[1];
		
		}
		
	// compares x point vs. rectangle x coordinates
		
	if ( X1 > PX ) {

		return 0;
		
		}
	
	if ( X2 < PX ) {

		return 0;
		
		}
		
	 // compares y point vs. rectangle y coordinates
		
	if ( Y1 < PY ) {

		return 0;
		
		}
	
	if ( Y2 > PY ) {

		return 0;
		
		}
	
	return inside;

	}

