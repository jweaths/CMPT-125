/*
 * Filename: values.c
 *
 * Description: reads floating point value from stdin, then outputs:
 *		-smallest integer less than or equal to value
 *		-nearest integer to this valye with hallway values rounded away from zero
 *		-largest integer smaller than or equal to this value
 *
 *
 * Author: JW
 * Date: May 24 2022
 */
 
 #include <stdio.h>
 #include <math.h>
 
 int main( void ) {
 
 	float userNum = 0;
 	float smallestLarger = 0;
 	float nearest = 0;
 	float largestSmaller = 0;
 	
 	printf("Please, enter a floating point value: ");
 	scanf("%f", &userNum);
 	
 	smallestLarger = ceil(userNum);
 	nearest = round(userNum);
 	largestSmaller = floor(userNum);
 	
 	printf("the smallest integer larger than or equal to %f is %d.\n", userNum, (int)smallestLarger);
 	printf("The nearest interger to %f is %d.\n", userNum, (int)nearest);
 	printf("The largest integer smaller than or equal to %f is %d.\n", userNum, (int)largestSmaller);
 	
 	return 0;
 	
 	
 	}
 
 
 
 
