/*
 * Filename: apples.c
 *
 * Description: prompt user to enter number of apples
 *		prompt user to enter the number of bags to hold apples
 *		all bags hold the same number of apples
 *		display the number of bags produced and the number of apples left over
 
 *
 *
 * Author: JW
 * Date: May 24 2022
 */
 
#include <stdio.h>

int main( void ) {
 
	int appleNum = 0;
	int bagSpace = 0;
	int bagsMade = 0;
	int applesIn = 0;
	int leftovers = 0;
	int run = 1;
	 
	while ( run = 1) {
		
		printf("Please, enter the number of apples available and the number of apples each bag holds: ");
		scanf("%d", &appleNum);
		scanf("%d", &bagSpace);
		
		if (appleNum == EOF) {
		
		run = 0;
		
		}
			
		
		printf("Number of apples available => %d, number of apples each bag holds => %d.\n", appleNum, bagSpace);
		 
		 
		bagsMade = (appleNum / bagSpace);
		applesIn = bagsMade * bagSpace;
		leftovers = appleNum - applesIn;
		printf("Number of bags produced => %d, number of apples leftover => %d.\n", bagsMade, leftovers);
		
		}
	
	printf("Done\n");
		
	return 0;
	}
	
	
 
 
 

