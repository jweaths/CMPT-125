/*
 * Filename: bits.c
 *
 * Description: outputs memory size (in bits) of 10 numerical data types in C.
 *
 *
 * Author: JW
 * Date: May 24 2022
 */
 
 #include <stdio.h>
 
 int main( void ) {

 
 
	printf("An unsigned char is stored in %ld bytes. \n", sizeof( char ));
	printf("An signed char is stored in %lu bytes. \n", sizeof( unsigned char ));
	printf("An unsigned short is stored in %ld bytes. \n", sizeof( short ));
	printf("An signed short is stored in %lu bytes. \n", sizeof( unsigned short ));
	printf("An unsigned int is stored in %ld bytes. \n", sizeof( int ));
	printf("An signed int is stored in %lu bytes. \n", sizeof( unsigned int ));
	printf("An unsigned long is stored in %ld bytes. \n", sizeof( float ));
	printf("An signed long is stored in %lu bytes. \n", sizeof( unsigned int ));



	return 0;
	
	}
