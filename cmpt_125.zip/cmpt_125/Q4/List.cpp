/*
 * List.cpp - D105-106
 * 
 * Class Description: An linked list-based implementation of a List data collection class. 
 *
 * Modified on: August 2022
 * Author: AL and 
 */                   

#include <cstdio>   // Needed for NULL
#include <iostream>
#include <climits>  // Needed for INT_MIN
#include "Node.h"
#include "List.h"

using namespace std;
	
// Default constructor
// Not to be modified!
List::List() {
  elementCount = 0;
  head = NULL;
  tail = NULL;
}

// Destructor
// Not to be modified!
List::~List() {
  while ( getElementCount() > 0 )
    removeAtFront();
} 

// Description: Returns the current number of elements in the List.
// Postcondition: List unchanged.
// Time Efficicency: O(1)
// Not to be modified!
unsigned int List::getElementCount() const {
  return elementCount;
}

// Description: Inserts "newElement" at the front of the List 
//              and returns true if successful, false otherwise.
// Time Efficicency: O(1)    
bool List::insertAtFront( int newElement ) {
	
  bool result = true;
  
  Node* newNode = new Node;
  
  if( newNode == NULL)
  {
  
  	result = false;
  	return result;
  
  }
  
  newNode->data = newElement; // sets up newNode with user's element
  newNode->next = head;
  
  head = newNode;
  
  elementCount = getElementCount() + 1;
  
  return result;
} 

// Description: Removes the element from the front of the List 
//              and returns true if successful, false otherwise. 
// Precondition: List is not empty.
// Time Efficicency: O(1)
// Not to be modified!
bool List::removeAtFront( ) {

  bool result = true;
  
  if ( head ) {
    Node* tobeRemoved = head;
    head = head->next;
    
    tobeRemoved->next = NULL;
    delete tobeRemoved;
    tobeRemoved = NULL;
      
    if ( head == NULL ) tail = NULL;
    
    elementCount--; 
  }
  else 
    result = false;
  
  return result;
} 

// Description: Finds and returns via the parameter the element 
//              in the List which has the maximum value
//              and returns true if successful, false otherwise. 
// Precondition: List is not empty.
// Postcondition: List unchanged.
// Time Efficicency: O(n)
bool List::findMax( int * max ) const {
	
  bool result = true;

if(head == NULL)
{

max = NULL;
result = false;
return result;

}

else
{

  Node* current = head; // sets current
  int maxValue = current->data;
  
  
  while(current != NULL)
  {
  
  	if(maxValue < (current->next)->data)
  	maxValue = (current->next)->data;
  
  }
  
  max = &maxValue;
  
  return result;
}

}

// Description: Prints all elements in the List.
// Postcondition: List unchanged.
// Time Efficicency: O(n)
// Not to be modified!
void List::displayList() const {

  cout << "This List has " << elementCount << " elements: {";
  if ( head ) {
    Node * current = head;
    for ( unsigned int i = 1; i <= elementCount; i++ ) {
      cout << " " << current->data;
      current = current->next;
    }
  }
  cout << " }" << endl;
  return;
}
