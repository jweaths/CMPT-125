/*
 * testDriver.cpp - D105-106
 * 
 * Class Description: Tests the List data collection class.
 *
 *   *** Put your code anywhere you need! ***
 *   *** Feel free to use the existing code or modify/remove it! ***
 *
 * Modified on: August 2022
 * Author: AL and 
 */

#include <iostream>
#include <cctype>
#include <cstdlib>
#include "List.h"

using namespace std;

int main() {

  /* Variables declaration */
  List * aList = new List();  
  
  for(int i = 0; i < 6; i++)
  {
  
  	aList->insertAtFront( i );
  
  }
  


  /* Displaying the List */ 
  cout << "Displaying the List with " << aList->getElementCount( ) << " elements." << endl; 
  aList->displayList( );
  
  max = 10;
  
  
  aList->findMax( max );

  delete aList;
  aList = NULL;
  
  return 0;
}
