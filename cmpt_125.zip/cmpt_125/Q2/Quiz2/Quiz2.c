/*
 * 5
 * Filename: Quiz2.c
 *
 * Description: Simple operations on raster images
 *
 * Author: RV - 2014
 * Modified by: AL - 2022
 *
 * Completed by: <Put your name here>
 * Completion Date: June 28
 */

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/*-------------------------------------------------
  OPERATIONS ON A PIXEL
*/
           
/* Get the pixel in the array at coordinate (x,y). */
uint8_t get_pixel( const uint8_t array[], 
                   unsigned int cols, 
                   unsigned int rows,
                   unsigned int x,
                   unsigned int y )
{
	// Validate the parameters
	assert( array != NULL );
    assert( x < cols );
    assert( y < rows ); 
    return array[ y*cols + x ];
}

/* Set the pixel at coordinate (x,y) to the specified colour. */
void set_pixel( uint8_t array[], 
                unsigned int cols, 
                unsigned int rows,
                unsigned int x,
                unsigned int y,
                uint8_t colour )
{
	// Validate the parameters
	assert( array != NULL ); 
	assert( x < cols );
    assert( y < rows );
    array[ y * cols + x ] = colour;
    return;
} 

/* ---------------------- Quiz 2 ---------------------- */
/* Given a pixel located at coordinates (x,y) in the raster 
   image array[], print the colour of the pixel located
   directly above this given pixel on stdout.
*/
void print_pixel_above( const uint8_t array[],
                        unsigned int cols, 
                        unsigned int rows,
                        unsigned int x,
                        unsigned int y )
{
    // Put your code here
    
    int pixel = *(array + (x-1) * cols + y);
    
    printf("%d\n", pixel); // prints colour at point (row above) point x, y
     
    return;
} 

/*-------------------------------------------------
  OPERATIONS ON THE WHOLE IMAGE 
*/

/*
  Returns a pointer to a freshly allocated array that contains the
  same values as the original array, or a null pointer if the
  allocation fails. The caller is responsible for freeing the array
  later.
*/
uint8_t* copy( const uint8_t array[], 
               unsigned int cols, 
               unsigned int rows )
{
 	// Validate the parameter
	assert( array != NULL );

	uint8_t* ret = malloc(cols*rows*sizeof(uint8_t));
    if (!ret) {
        perror("Call to malloc failed\n");
        exit(1);
    }
    memcpy(ret, array, cols*rows*sizeof(uint8_t));
	
    return ret;
}

/* ---------------------- Quiz 2 ---------------------- */
/* Mask the left half of the image with the given mask_colour.
   In other words, replace the colour of all the pixels from the 
   leftmost edge of the image to the middle of the image
   such that when the image is displayed, only the right side 
   of the original image is displayed and its left side
   has been replaced by a rectangle of colour "mask_colour".
*/
void mask_left_side( uint8_t array[], 
                     unsigned int cols, 
                     unsigned int rows,
                     uint8_t mask_colour )
{
    // Put your code here
    
    for(int i = 0; i < rows; i++) { // iterates through rows
    
    	for(int k = 0; k < (cols % 2); k++) { // iterates first half of columns
    	
    		array[(i*cols) + k] = mask_colour; //assigns mask colour value to pixel
    	
    	}
    
    }
    
    return;
}
