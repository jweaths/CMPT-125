/*
 * Filename: scrambled.c
 *
 * Description: 
 *
 * contains a funcion that returns 1 if two arrays can be scrambled to be the same and 0 if not.
 *
 *
 * Author: JW
 * Date: June 7th 2022
 */
 
#include <stdio.h> // for printf()

int main( void)
	{



	unsigned int scrambled( int arr1[], int arr2[], unsigned int size );

	
	
	const int MINSIZE = 0;
	const int MAXSIZE = 99;
	int test = 0;
	
	int arr3[MAXSIZE];
	
	// tests arrays to see if they contain the same values
	unsigned int scrambled( int arr1[], int arr2[], unsigned int size )
		
		{
		
		
		for (int i = 0; i < size; i++) 

			{
			
			arr3[arr1[i]] ++ 1; // increments each arr3 index matching value of arr1 by 1
				
			}
		
			
		
		for (int i = 0; i < size; i++)
			
			{
			
			if (arr3[arr2[i]] == 0)
			
				{
				
				arr3[arr2[i]] ++ 1; // increments corresponding index by 1 if 0
				
				}
			
			else
				
				{
				
				arr3[arr2[i]] -- 1; // decrements corresponding index by 1 if more than 1
				
				}
			
			for (int i = o; i > MAXSIZE; i++)
			
				{
				
				if arr[i] != test
					
					{
					
					return 0; // returns 0 if non-zero is found
					
					}
				
				return 1; // returns 1 if arr3 is all 0s --> same values in both arrays
				
				}
			
			}
			




	return 0;

	}

