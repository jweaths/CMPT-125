/*
 * Filename: imgops.c
 *
 * Description: Simple operations on raster images
 *
 * Author: RV - 2014
 * Modified by: AL - 2022
 *
 * Completed by: <Put your name here>
 * Completion Date: 
 */

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/*-------------------------------------------------
  OPERATIONS ON A PIXEL 
*/

/* Get the pixel in the array at coordinate (x,y). */
uint8_t get_pixel( const uint8_t array[], 
                   unsigned int cols, 
                   unsigned int rows,
                   unsigned int x,
                   unsigned int y ) 
{	   
    assert( x < cols );
    assert( y < rows );
    return array[ y * cols + x ];
}

/* Set the pixel at coordinate (x,y) to the specified color. */
void set_pixel( uint8_t array[], 
                unsigned int cols, 
                unsigned int rows,
                unsigned int x,
                unsigned int y,
                uint8_t color ) 
{
    assert( x < cols );
    assert( y < rows );
    array[ y * cols + x ] = color;
    return;
} 

/*-------------------------------------------------
  OPERATIONS ON THE WHOLE IMAGE 
*/

/* Set every pixel to zero 0 (black). */
void zero( uint8_t array[],
	   unsigned int cols,
	   unsigned int rows ) {

		memset(array, 0, sizeof(uint8_t) * rows * cols); //sets every arr val to 0

}
/*
  Returns a pointer to a freshly allocated array that contains the
  same values as the original array, or a null pointer if the
  allocation fails. The caller is responsible for freeing the array
  later.
*/

uint8_t* copy( const uint8_t array[], 
               unsigned int cols, 
               unsigned int rows )
{

    uint8_t* arrCopy = malloc(sizeof(uint8_t) * cols * rows); // assigns dynamic heap
    
    for(int i = 0; i < rows * cols; i++) {
    	
    	arrCopy[i] = array[i];	// copies array onto new array in heap
    	
    	if( arrCopy[i] != array[i]) {
    		
    		return NULL; // returns null if it doesn't copy
    		
    		}
    	
    	printf("%d", arrCopy[i]); //TEST print
    	
    	}
    	
    return arrCopy;

}

/* Return the darkest color that appears in the image. */
uint8_t darkest( const uint8_t array[], 
                 unsigned int cols, 
                 unsigned int rows )
{
    // Put your code here
    
    unsigned int lowestValue = 256;
    
    for(int i = 0; i < rows * cols; i++) {
    	
    	
    	if(array[i] < lowestValue) {
    	
    		lowestValue = array[i];
    	
    	}
    
    }
    
    return lowestValue; // You will need to change 0 to something more appropriate.
}

/* Return the lightest color that appears in the image. */
uint8_t lightest( const uint8_t array[], 
	              unsigned int cols, 
	              unsigned int rows )
{
	// Put your code here
	
	unsigned int highestValue = 0;
	
	for(int i = 0; i < rows * cols; i++) {
	
		if(array[i] > highestValue) {
		
			highestValue = array[i];
		
		} 
	
	}
	
	return highestValue; // You will need to change 0 to something more appropriate.
}

/* Replace every instance of pre_color with post_color. */
void replace_color( uint8_t array[], 
                    unsigned int cols, 
                    unsigned int rows,
                    uint8_t pre_color,
                    uint8_t post_color )
{
	// Put your code here
	
	for(int i = 0; i < rows * cols; i++) {
	
		if(array[i] = pre_color) {
		
			array[i] = post_color;
		
		}
	
	}
	
	return;
}

/* Flip the image horizontally, left-to-right, like in a mirror. */
void flip_horizontal( uint8_t array[], 
                      unsigned int cols, 
                      unsigned int rows )
{
    // Put your code here
    
    unsigned int temp = 0;
    
    for( int i = 1; i <= rows * cols; i++) { // iterates through array
    
    	if( i % cols == 0 ) { // integer division, if division of index rounds to 0
    	
    		for(int j = i, int k = i + cols - 1; j < i+(cols)/2; j++, k--) {
    		
    			temp = array[j] = array[k];
    			array[j] = array[k];
    			array[k] = temp;
    		
    		}
    	
    	}
    
    }
    
}


/* Find the coordinates (x,y) of the first pixel with a value that
   equals color. Search from left-to-right, top-to-bottom. If it is
   found, store the coordinates in *x and *y and return 1. If it is
   not found, return 0.
*/
int locate_color( const uint8_t array[],              
                  unsigned int cols, 
                  unsigned int rows,
                  uint8_t color,
                  unsigned int *x,
                  unsigned int *y )
{
    // Put your code here
    
    for( int i = 0, int k = 0; i < rows; i++) {
    
    	for( int j = 0; j < cols; j++, k++ ) {
    	
			if ( array[k] == color ) { // k acts as a counter
				
				*x = i;
				*y = j;
				
				return 1;
				
			}
    	
    	}
    
    }
    
    return 0;  // You will need to change 0 to something more appropriate.
}

/* Invert the image such that black becomes white and vice
   versa and light shades of grey become the corresponding dark
   shade.
*/
void invert( uint8_t array[], 
             unsigned int cols, 
             unsigned int rows )
{
    // Put your code here
    
    for(int i = 0; i < rows * cols; i++) {
    
    	array[i] = 255 - array[i]; //inverts colours
    
    }
    
	return;
}
