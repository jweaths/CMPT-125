#include <stdlib.h> // for malloc() and for rand()
#include <stdio.h>  // for file i/o calls
#include <time.h>   // for time()
#include <string.h> // for strlen()

#include "dataStructure.h"

int main( void ) {

	list_t* headPtr = list_create();


	// element_t* node1 = element_create(10);

	for(int i = 1; i <= 10; i++) {

	list_append(headPtr, rand() % 10); // APPEND TEST.

	}


result_t result = list_print(headPtr); // LIST PRINT.

//	element_t* getResult = list_get(headPtr, 5); // GET TEST.

//	printf("%d\n", getResult->val); // GET MATCH.

//  element_t* findResult = list_find(headPtr, 2); // FIND TEST.

//	printf("%d\n", findResult->val); // FIND MATCH.

// list_removeFront(headPtr);

// list_print(headPtr);

// element_t* test = element_create(10);

// printf("%d\n", test->val);

// list_t* test2 = list_create;

// printf("%p\n", test2->head);

// printf("%p\n", test2->tail);

// printf("%p\n", test2->elementCount);


list_destroy(headPtr);



list_print(headPtr);



















	return 0;

}
