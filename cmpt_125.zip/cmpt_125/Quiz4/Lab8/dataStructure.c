/*
 * dataStructure.c
 *
 * Provides a data structure made of a doubly-headed singly-linked list (DHSL)
 * of unsorted elements (integers) in which duplicated elements are allowed.
 *
 * A DHSL list is comprised of a single header and zero or more elements.
 * The header contains pointers to the first and last elements in the list,
 * or NULL if the list is empty. The first element contains a pointer to
 * the next element, and so on. The last element in the list has its
 * "next" pointer set to NULL.
 *
 * The interface of this data structure includes several utility
 * functions that operate on this data structure.
 *
 * Precondition: Functions that operate on such data structure
 *               require a valid pointer to it as their first argument.
 *
 * Your name: Jack Weatherbe
 * Modified Date: 07-17-2022
*/

#include <stdio.h>
#include <stdlib.h>

#include "dataStructure.h"



    // LIST_CREATE (FIRST) (PARTIAL)
/*
 * Description: Creates a new empty data structure of list_t type and
 *              if successful, returns a pointer to it.
 *              If unsuccessful, returns NULL.
 * Time Efficiency: O(1)
 */
list_t* list_create( void ) {

  list_t* aList = malloc( sizeof(list_t) ); // allocates space for empty list
  aList->head = NULL; // sets head pointer to NULL
  aList->tail = NULL; // sets tail pointer to NULL
  aList->elementCount = 0; // sets element count for zero

  if(aList == NULL) { // if allocation fails...

    return NULL;

  }

  return aList;

}



    // LIST_DESTROY
/*
 * Description: Frees all memory used by the data structure pointed to by "list".
 *              Returns OK.
 * Time Efficiency: O(n)
 */
result_t list_destroy( list_t* list ) {

  if(list != NULL) {


  printf("list destroy\n");

  element_t* current = list->head; // pointer to first element in list



  element_t* nextNode; // pointer to next node



 list->head = NULL;
 list->tail = NULL;
 list->elementCount = 0;



 free(list->head); // frees list memory at address
 free(list->tail);



 while(current != NULL) {

    nextNode = current->next; // prepares address for the next iteration

    free(current); // frees node memory at address

    current = nextNode; // sets current address to nextNode

  }


  free(list);
  list = NULL;


}
  return OK;

}


    // ELEMENT_CREATE (SECOND)
/*
 * Description: Returns a pointer to a new element i.e., a node
 *              containing "newElement" and a next-pointer set to NULL,
 *              or NULL if memory allocation fails.
 * Time Efficiency: O(1)
 */
element_t* element_create( int newElement ) {



  element_t* anElement = malloc( sizeof(element_t) ); // allocates space for empty node

  anElement->val = newElement; // assigns the value of the node to the element entered

  anElement->next = NULL; // sets next value to empty


  if(anElement == NULL) { // if allocation fails...

    return NULL;


  }

  return anElement;
}



  // LIST_APPEND
/* Description: Appends a new element, i.e., a node containing "newElement",
 *              to this data structure pointed to by "list" and returns OK.
 *              If "newElement" cannot be appended, leaves the
 *              data structure unmodified and returns ERROR.
 *              Returns NULL_PARAM if "list" is NULL.
 * Time efficiency: O(1)
 */

result_t list_append( list_t* list, int newElement ) {

  result_t result = OK; // default

  if(list == NULL) { // if the list is empty...

    return NULL_PARAM;

  }

  element_t* node = element_create(newElement);

  if( list->elementCount == 0 ) { // if the list is empty

    list->head = node; // head pointer points to the new node
    list->tail = node; // tail pointer points to the new node
    list->elementCount++; // makes element count = 1

  }
  else {

    (list->tail)->next = node; // sets the last node's next pointer to address of new node
    list->tail = node; // sets the tail value of the head pointer
    list->elementCount++; // increments the element count of the header

  }

  if(list->tail == NULL) { // if allocation fails

    return ERROR; // return error

  }


  return result; // return OK

}



    // LIST_PREPEND (COMPLETE)
/* Description: Prepends a new element, i.e., a node containing "newElement",
 *              to this data structure pointed to by "list" and returns OK.
 *              If "newElement" cannot be prepended, leaves the
 *              data structure unmodified and returns ERROR.
 *              Returns NULL_PARAM if "list" is NULL.
 * Time efficiency: O(1)
 */
result_t list_prepend( list_t* list, int newElement ) {

  result_t result = OK; // default

  if ( list == NULL ) {

    result = NULL_PARAM; // Returns NULL_PARAM if "list" is NULL.

  }

  else {

    element_t* anElement = element_create( newElement ); // Creates a new element (node) containing "newElement"

    if ( anElement == NULL ) result = ERROR; // if memory allocation fails

    else {

      if ( list->tail == NULL ) // Empty list

        list->tail = anElement; // assigns list node tail pointer to new node

      if ( list->head ) // Non-empty list

        anElement->next = list->head; // assgins the new node's next pointer to the address of the first element in the list

      list->head = anElement; // sets the header pointer of list node to address of new node

      list->elementCount++; // One more element in the list

    }

  }

  return result;

}



    // LIST_REMOVE_FRONT (INCOMPLETE)
/* Description: Removes the front (first) element (node) in the data
 *              structure pointed to by "list" and returns OK.
 *              If no elements (no nodes) can be removed, leaves the
 *              data structure unmodified and returns ERROR.
 *              Returns NULL_PARAM if "list" is NULL.
 * Time efficiency: O(1)
 */

result_t list_removeFront( list_t* list ) {

  result_t result = OK;

  if ( list == NULL ) { // if list node is empty...

    result = NULL_PARAM;

  }

  else {

    element_t* newHead = (list->head)->next; // points to second node in list

    free(list->head); // destroys node at memory address list head

    list->head = newHead; // replaces with the original second element in the list

  }

return result;

}




      // LIST_GET (INCOMPLETE)
/* Description: Returns a pointer to the element (i.e., to the node) at
 *              "position" in the data structure pointed to by "list".
 *              The head of "list" is at "position" 0, the first element
 *              (node) in "list" is at "position" 1, etc. Returns NULL
 *              if "position" is out of range. Returns NULL if "list" is NULL.
 *              This function does not modify the data structure.
 * Time efficiency: O(n)
 */
element_t* list_get( list_t* list, unsigned int position ){

  element_t* anElement = NULL;

  if(list->head == NULL) { // if list is empty

    return NULL;

  }

  element_t* current = list->head; // equal to first node in list

  unsigned int index = 0; // tracks index position

  while(current->next != NULL && index <= position) {

    if(index == position) {


      anElement = current;
      return anElement; // returns pointer to current node that equals target position

    }

    index++;
    current = current->next; // sets current pointer to the next node

  }

  return NULL; // if next becomes null before index and exits loop

}


    // LIST_FIND
/* Description: Returns a pointer to the element (i.e., to the node) that
 *              contains the first occurrence of "targetElement" in the data
 *              structure pointed to by "list". Returns NULL if "targetElement"
 *              is not found. Returns NULL if "list" is NULL.
 *              This function does not modify the data structure.
 * Time efficiency: O(n)
 */
element_t* list_find( list_t* list, int targetElement ) {

  element_t* anElement = NULL;

  if(list == NULL) {

    return NULL;

  }

  element_t* current = list->head;

  while(current->next != NULL) {

    if(targetElement == current->val) {

      anElement = current;
      return anElement;

    }

    current = current->next;

  }


  return NULL;

}



      //LIST_PRINT (COMPLETE)
/* Description: Prints the content of the data structure pointed to by "list",
 *              in human-readable form from the first element
 *              to the last element, between curly braces, then returns OK.
 *              Returns NULL_PARAM if "list" is NULL.
 *              This function does not modify the data structure.
 * Time Efficiency: O(n)
 */
result_t list_print( list_t* list ) {

  result_t result = OK;
  printf("start list print\n");
  // Returns NULL_PARAM if "list" is NULL.
  if ( list == NULL ) result = NULL_PARAM;
  else {

    printf( "This data structure has %d element%c:\n", list->elementCount,
             list->elementCount > 0 ? 's': ' ' );
    printf( "{" );

    // Prints each element
    for ( element_t* eachElement = list->head; eachElement; eachElement = eachElement->next )
      printf( " %d", eachElement->val );

    printf( " }\n" );
    printf("Function Complete");
      return result;
  }
  printf("empty list");
  return result;
}
