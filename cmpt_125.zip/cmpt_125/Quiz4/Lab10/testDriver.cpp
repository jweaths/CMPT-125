/*
 * palindromeChecker.cpp
 *
 * Class Description: C++ program that determines when a given word is a palindrome.
 *                    Note that words of length 1 are palindromes.
 *
 * Author:
 * Date:
 */

#include <iostream>
#include <cstring>
#include <cctype>
#include "Stack.h"

using namespace std;

int main() {

  /* Some variables declaration - you may need more. */
  Stack* aStack = new Stack();
  string theWord = ""; // user input word
  string backWord = ""; // for storing string backwards
  bool empty; // for isEmpty function



  /* Prompt user for a word and read the word. */
  cout << "Please, enter a word: ";
  /* Remove all leading whitespace -> ws */
  getline(cin >> ws, theWord);




  for(int i = 0; i < theWord.length() ; i++ ) // iterates throught theWord
  {



    char letter = theWord[i]; // extracts index letter from word

    aStack->push(letter); // pushes letter to aStack



  }

  empty = aStack->isEmpty();

  if( empty == false )
  {

    char lastLetter = aStack->peek();

    cout << "The last letter of this word is " << lastLetter << "." << endl;

  }

  else
  cout << " The stack is empty." << endl;;



  for(int i = 0; i < theWord.length(); i++ )
  {




    char letter = aStack->pop(); // pushes letter to aStack

    backWord+=letter; // increments letter to word



  }

  if(backWord == theWord) // if backword has the same word as the word
  {

    cout << "This is a palendrome." <<endl;

  }

  else // if the two variables are different
  cout << "This is not a palendrome." <<endl;

  return 0;
}
