/*
 * Stack.cpp
 *
 * Class Definition: stack based linked list
 *
 * Created on:
 * Author: JW
 */

#include <cstdio>    // Needed for NULL
#include <iostream> // for printing
#include "Stack.h" // header file



using namespace std;


// constructor
Stack::Stack() {

setHead(NULL);
// head = NULL;

}


void Stack::push( char letter ) // since I'm calling through an object, just using head is fine
{

  StackNode* newNode = new StackNode; // creates new stack node

  // check if memory allocation fails

  newNode->data = letter;  // takes user input and assigns it to the newNode data
  newNode->next = getHead(); // sets the next value to the current head

  setHead(newNode); // The new Node becomes the head (newNode places on top of stack)

}

Stack::StackNode* Stack::getHead() const //returns a the head pointer
{

  return head; // returns the head pointer

}

void Stack::setHead(StackNode* s) // sets the head pointer
{

  head = s; // sets head to the User input node address

}

char Stack::pop()
{

  char poppedNode = getHead()->data; // stores the pointer to first node in the list
  StackNode* newHead = getHead()->next; // stores the pointer to second node in the list

  setHead(newHead); // replaces first node pointer with second node pointer as head

  return poppedNode; // returns the former first node as the popped node

}

char Stack::peek() const // Description: Returns the topmost element of the stack.
{

// NOTE: check if head = NULL in the testDriver beforehand

char peeking = getHead()->data; // alias of first letter into peeking

return peeking; // return the character


}

bool Stack::isEmpty() const
{

  if(getHead() == NULL) // if the Stack head points to NULL
  {

    return true;

  }

  else // if the Stack head points to a node
  return false;
// could be one line with boolean operator
}

// end Node.cpp
