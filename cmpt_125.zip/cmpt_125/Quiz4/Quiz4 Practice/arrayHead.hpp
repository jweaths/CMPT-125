/*
 * Stack.h
 *
 * Description: Implementation of a SHSL / Array based Stack of char with push/pop ...
 * Class Invariant: ... in a LIFO order.
 *
 * Author: JW
 * Date: July 29 2022
 */

 #pragma once

 class ArrayStack { // list with stack class invariant

 private:

   unsigned const int DEFAULT_CAP = 10;
   unsigned int size;
   unsigned int headIndex;
   char* array;


 public:



      // CONTRUCTORS


   // default constructor - creates list with default capacity
   ArrayStack();

   // parameterized constructor - creates array stack based on size
   ArrayStack( unsigned int arraySize);


      // SETTERS


   // Setter for head value
   void setHeadIndex(int newIndex);

   // Setter for size value
   void setEC( int n );

   // Setter for Array
   void setArray( char* arr );


      // GETTERS


   // Getter for size value
   int getEC() const;

   // Getter for array
   char* getArray() const;

   // Getter for head value
   int getHeadIndex() const;


      // STACK BASED FUNCTIONS


   // Pushes new element into list (STACK)
   void pushArray( char val);

   // returns the first element of the list, does not remove / change it (STACK)
   char peekArray() const;

   // returns first element / removes / replaces with the second element in the array
   char popArray();

   // checks if stack / array is empty
   bool isEmpty();

   void displayList() const;


 };


 class ArrayList { // Array-based list

 private:

   unsigned static const DEFAULT_SIZE = 20;
   unsigned int size;
   unsigned int elementCount;
   int* array;

 public:

   // Default Constructor
   ArrayList();

   // Parameter Constructor
   ArrayList( unsigned int arraySize );

   // Destructor
  ~ArrayList();

      // GETTERS

    //size getter

    unsigned int getSize() const;

    unsigned int getEC() const;

    int* getArray() const;


      // SETTERS

    void setSize( unsigned int arraySize );

    void setEC( unsigned int ec);

    void setArray( int* array1 );

    // LIST ARRAY FUCTIONS

    void insert( int newPosition, int newElement );

    void remove( int position );

    void removeAll();

    int getElement( int position ) const;

    void displayList() const;



 };

 class LinkedList
 {

 private:

   class Node
   {

    public:
      int data;
      Node* next;

   };

   Node* head;

 public:

   // constructor
   LinkedList();


   // destructor
   ~LinkedList();

   // SETTERS
   void setHead( Node* header );

   // GETTERS
   LinkedList::Node* getHead() const;



    // Linked-List based function

    void insertLinked( int element, int position );
    
    void removeLinked( int position);
    
    void removeAllLinked();
    
    int getElementLinked( int position);
    
    void displayLinkedList();
    
    
    
    





 };
