#include <iostream>
#include <cstring>
#include <cctype>
#include "arrayHead.hpp"

using namespace std;

int main()
{



LinkedList* aList = new LinkedList;

for( int i = 0; i < 10; i++ )
{

	aList->insertLinked( 10, i );

}


return 0;

}
