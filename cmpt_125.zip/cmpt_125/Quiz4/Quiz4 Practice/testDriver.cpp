#include <iostream>
#include <cstring>
#include <cctype>
#include "arrayHead.hpp"

using namespace std;

int main()
{

  string theWord = ""; // user input word
  string backWord = ""; // for storing string backwards


  ArrayStack* arrayStacked = new ArrayStack();


  /* Prompt user for a word and read the word. */
  cout << "Please, enter a word: ";
  /* Remove all leading whitespace -> ws */
  getline(cin >> ws, theWord);

  for(int i = 0; i < theWord.length() ; i++ ) // iterates throught theWord
  {

    char letter = theWord[i]; // extracts index letter from word

    arrayStacked->pushArray(letter); // pushes letter to aStack

  }


  arrayStacked->displayList(); // prints our stacked array after push



  for(int i = 0; i < theWord.length(); i++ )
  {




    char letter = arrayStacked->popArray(); // pushes letter to aStack

    backWord+=letter; // increments letter to word



  }



arrayStacked->displayList(); // prints our stacked array after pop




  cout << backWord << endl;
  if(backWord == theWord) // if backword has the same word as the word
  {

    cout << "This is a palendrome." <<endl;

  }

  else // if the two variables are different
  cout << "This is not a palendrome." <<endl;


  return 0;

}
