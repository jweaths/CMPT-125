/*
 * StackArray.cpp
 *
 * Class Definition: stack / array based linked list
 *
 * Created on: July 29 2022
 * Author: JW
 */

 #include <cstdio>    // Needed for NULL
 #include <iostream> // for printing
 #include "arrayHead.hpp" // header file
using namespace std;

//default contructor
ArrayStack::ArrayStack() : size(DEFAULT_CAP), headIndex(0), array(new char[DEFAULT_CAP]) {}

// parameterized constructor
// ArrayStack::ArrayStack( unsigned int arraySize)

ArrayStack::ArrayStack( unsigned int arraySize )
  {

    setEC(arraySize); // sets the starting size
    char* newArray = new char[size]; // allocates space for new array
    setArray(newArray); // sets newArray as the array pointer

    setHeadIndex(0);

  }


    // GETTERS


// Head Index Getter
int ArrayStack::getHeadIndex() const
  {

    return headIndex;

  }


// Element Count Getter
int ArrayStack::getEC() const
{

  return size;

}

// Array Getter (returns pointer to array used in stack)
char* ArrayStack::getArray() const
{

  return array;

}

    // SETTERS



// Array Pointer Setter
void ArrayStack::setArray( char* arr)
{

    array = arr;

}


// Head Index Setter
void ArrayStack::setHeadIndex(int newIndex)
{

  headIndex = newIndex;

}


// Size Setter
void ArrayStack::setEC( int n ) // same with this one. It needs an array version
{

  size = n;

}


// STACK BASED FUNCTIONS


// pushes element onto array (STACK INVARIANT)
void ArrayStack::pushArray( char val )
{


  int head = getHeadIndex(); // retrieves current head index

  int newHead = head + 1; // increments the current to get the new



  *( getArray() + newHead ) = val; // sets the value at the new head

  setHeadIndex(newHead); // labels the new element as the head



}

// pops element off of array (STACK INVARIANT)
char ArrayStack::popArray()
{

  int indexToPop = getHeadIndex(); // gets index of head (back of list)

  char* array = getArray(); // gets array pointer

  int popped = *( array + indexToPop ); // retrieves value to return

  int newHead = indexToPop - 1;

  setHeadIndex(newHead); // sets head of list to one less

  return popped; // return the popped character

}


void ArrayStack::displayList() const
{

  char* arr = getArray();
  unsigned int count = getHeadIndex();

  for(int i = 0; i <= count ; i++)
  {

    cout << *(arr + i) << endl;


  }

}

// ARRAY LIST FUNCTIONS

ArrayList::ArrayList() : size(DEFAULT_SIZE), elementCount(0), array( new int[size]) {}

ArrayList::ArrayList( unsigned int arraySize)
{

  size = arraySize;
  elementCount = 0;
  array = new int[size];

}

  // GETTERS

unsigned int ArrayList::getSize() const
{

  return size;

}

unsigned int ArrayList::getEC() const
{

  return elementCount;

}

int* ArrayList::getArray() const
{

  return array;

}

  // SETTERS


void ArrayList::setSize( unsigned int arraySize )
{

  size = arraySize;

}

void ArrayList::setEC( unsigned int ec)
{

  elementCount = ec;

}

void ArrayList::setArray( int* array1 )
{

  array = array1;

}

  // ARRAY LIST-BASED FUNCTIONS

void ArrayList::insert( int newPosition, int newElement )
{

  int* array = getArray();
  unsigned int elementCount = getEC();

  for(int i = newPosition; i <= elementCount; i++)
  {

    *(array + i + 1) = *(array + i);

  }

  *(array + newPosition) = newElement;
  setEC( elementCount + 1);

}

void ArrayList::remove( int position )
{

  int* array = getArray();
  unsigned int elementCount = getEC();

  for(int i = position; i < elementCount; i++)
  {

    *(array + position) = *(array + position + 1);

  }

  setEC( elementCount - 1);

}

void ArrayList::removeAll()
{

  setEC( 0 );

}

int ArrayList::getElement( int position ) const
{
  int* array = getArray();
  unsigned int elementCount = getEC();

  return *(array + position);

}

void ArrayList::displayList() const
{

  int* array = getArray();
  unsigned int elementCount = getEC();

  for(int i = 0; i < elementCount; i++)
  {

    cout << *(array + i);

  }

}

  // LINKED_LIST BASED FUNCTIONS

LinkedList::LinkedList()
{

  head = NULL;

}

void LinkedList::setHead( Node* header )
{

  head = header;


}

LinkedList::Node* LinkedList::getHead() const
{

  return head;

}

void LinkedList::insertLinked( int element, int position ) // position being index
{

  Node* current = getHead();
    cout << "1" << endl;
  Node* newNode = new Node;
  
  cout << "2" << endl;
  int i = 0; // index to track position

  if(position > 0)
  {
	cout << "3" << endl;
    while( i != position - 1 )  // iterates to the node before position
    {

      current = current->next;
	cout << "4" << endl;
    }

    Node* setUp = current->next; // stores node at index position
    current->next = newNode; // makes node before position point to new node
	cout << "5" << endl;
    newNode->data = element; // stores data value in new node
    newNode-> next = setUp; // makes node point to the node it replaced
	cout << "6" << endl;
  }

  else
  {
cout << "7" << endl;
    newNode->data = element; // fills new node data
    newNode->next = current; // new node points to the head
cout << "8" << endl;
    setHead(newNode); // new node becomes new head

  }


}

void LinkedList::removeLinked( int position)
{

  Node* current = getHead();
  int i = 0; // index to track position

  if(position > 0)
  {

    while( i != position - 1 )  // iterates to the node before position
    {

      current = current->next;
      i++;

    }

    Node* toRemove = current->next; // stores node at index position
    current->next = toRemove->next; // makes node before position point to new node

    delete toRemove;
    

  }
  
  else
  {
  
  	Node* newHead = current->next;
  	setHead(newHead);
  	
  	delete current;
  
  }


}

void LinkedList::removeAllLinked()
{

	Node* current = getHead(); // current set to head
	
	
	while( current != NULL )
	{
	
	
		Node* temp = current->next; // stores pointer of next node (replaced every time
		delete current;
		current = temp;
	
	
	}
	
	setHead(NULL);

}

int LinkedList::getElementLinked( int position )
{


	Node* current = getHead(); // current set to head
	int i = 0; // tracker
	
	
	while( current != NULL )
	
	{
		if(i == position)
		{
		
			return current->data;		
			
		}
		
		current = current->next;
	
	}
	
}

void LinkedList::displayLinkedList()
{



	Node* current = getHead(); // current set to head
	
	while( current )
	{
	
		cout << current->data << endl;
	
	}
	
}
	
	






