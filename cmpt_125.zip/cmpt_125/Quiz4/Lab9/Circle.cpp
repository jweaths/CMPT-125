/*
* Circle.cpp
*
* Description: ...

* Author: JW
* Modification date: July 2022
*/

#include <iostream> // for printing
#include <cmath> // for pi (M_PI)
#include "Circle.h" // our header file


using namespace std; // useful, I don't know why though

// METHOD IMPLEMENTATIONS

// The Circle:: preceding each method indicates that the method belongs to the Rectangle class.
// If it is omitted, the compiler will attempt to create a separate function
// (not belonging to the class). This is not what we want.

// Default Contructor: the default contructor has no parameters
// Description: contructs a circle of radius = DEFAULT_RAD and x/y = DEFAULT_POS

Circle::Circle() : x(DEFAULT_POS), y(DEFAULT_POS), radius(DEFAULT_RAD) {}

// Note: This part of the constructor's header
//       " : radius( DEFAULT_RAD ), x( DEFAULT_POS ), y( DEFAULT_POS)"
//       is called the "initialiation list".

// Parameterized constructor: A constructor with parameters for radius, x and y.
// Description: Constructs a new Circle object with the given values for radius, x and y.
//              if the given radius is > 0
//              ensuring the class invariant remains true.
//              Otherwise, sets the radius to DEFAULT_RAD;

Circle::Circle( int cordX, int cordY, double aRadius ) {

x = cordX;
y = cordY;
radius = aRadius;


// Ensures invariant is satisfied

if ( aRadius <= 0 ) radius = DEFAULT_RAD; // Don't need {}s if there is only one line in the body.

}

/* Getters: Return information about the Circl. */

// Note the "const" at the end of the method.
// This guarantees that the method cannot alter the member variables

// Description: Returns the Circle's radius.
double Circle::getRadius() const {

  return radius;

}

// Description: Returns the Circle's x coordinate.
int Circle::getX() const {

  return x;

}

// Description: Returns the Circle's x coordinate.
int Circle::getY() const {

  return y;

}

/* Setters: change the values of the attributes. */

// Description: Sets the rectangle's width to aWidth iff aWidth > 0.
void Circle::setRadius( double aRadius ) {

    if ( aRadius > 0) radius = aRadius;
    else radius = DEFAULT_RAD;

    return;

  }

// Description: Sets the rectangle's x position to cordX
void Circle::setX( unsigned int cordX ) {

    x = cordX;

    return;

  }

// Description: Sets the rectangle's y position to cordX
void Circle::setY( unsigned int cordY ) {

    y = cordY;

    return;

  }

/* Methods - Specific to Problem Statement */

// Description: Moves the circle by given distances
void Circle::move( int horiz, int vert ) { // no const because we want to change these values

    x = getX() + horiz;
    y = getY() + vert;

    setX(x);
    setY(y);

    return;

  }

double Circle::computeArea() { // computes area of the circle

  double area = pow(getRadius(), 2) * M_PI; // squares radius and multiplies by pi

  return area;

  }

void Circle::displayCircle() { // prints circle values on std out

  cout << "x = " << getX()
       << ", y = " << getY()
       << ", radius = " << getRadius() << endl;

  }

bool Circle::intersect(Circle c) { // returns true if c intersects the calling circle.

    double r1 = getRadius(); // assigns default and new circles values to variables
    double r2 = c.getRadius();

    int x1 = getX();
    int x2 = c.getX();
    int y1 = getY();
    int y2 = c.getY();

    unsigned int distanceSquared = pow(x1-x2, 2) + pow(y1-y2, 2);
    double radiusSum  = pow(r1+r2, 2);

    if( distanceSquared == radiusSum || distanceSquared < radiusSum )
    return true;

    else
    return false;

  }

  // End of the implementation file
