/*s
* Circle.h
*
* Description: --
*
* Class Invariant: dimensions must be positive

* Author: JW
* Modification date: July 2022
*/

#pragma once


// Definition of circle class

class Circle {

// DATA

private: // Everything that follows is private and cannot be accessed outside classes

const double DEFAULT_RAD = 10;
const unsigned int DEFAULT_POS = 0;
double radius; // radius, cannot be negative
int x; // give coodinate x on a cartesian plane
int y; // give coordinate y on a cartesian plane

public: //Everything that follows is public and can be accessed outside classes

  // Methods specific to class
  // constructors

  // the default constructor has no parameters
  Circle();
  // description: contructs a circle on the xy plane


  Circle( int x, int y, double radius );


  // Since we are not dynamically allocating heap memory for the data members of this class,
  // we do not need to write a destructor and shall use the destructor provided by the system.


  // GETTERS - Return information about the rectangle

  // Note the "const" at the end of the statement
  // This guarentees that the method cannot alter the member variables


  // Description: returns circle's X.
  int getX() const;
  // Decription: returns circle's Y.
  int getY() const;
  // Description: returns circle's Radius.
  double getRadius() const;

  // SETTERS - change the value of attributes


  // Description: Sets circle's X coordinate to cordX
  void setX(unsigned int cordX);
  // Description: Sets circle's Y coordinate to cordY
  void setY(unsigned int cordY);
  // Description: Sets circle's radius to aRadius if aRadius > 0
  void setRadius( double aRadius);

  // METHODS - specific to problem statement

  void move( int horiz, int vert );

  double computeArea();

  void displayCircle();

  bool intersect(Circle c);






}; // Note the ";" - don't forget it!
/* End of Rectangle.h */
