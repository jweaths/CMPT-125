#include <stdlib.h> // for malloc() and for rand()
#include <stdio.h>  // for file i/o calls
#include <time.h>   // for time()
#include <string.h> // for strlen()

#include "dataStructure.h"

int main( void ) {

	intArray_t* arr1Ptr = intArray_create(20);

	for(int i = 0; i < arr1Ptr->size; i++) {


		intArray_append(arr1Ptr, rand() % 50);

	}


	// intArray_print(arr1Ptr);  // PRINT

	// intArray_remove(arr1Ptr, 10); // REMOVE

	// intArray_print(arr1Ptr); // PRINT

	// intArray_modify(arr1Ptr, 10, 5); // MODIFY

	// intArray_print(arr1Ptr); // PRINT

	// intArray_sort(arr1Ptr); // SORT

	// intArray_print(arr1Ptr);  // PRINT

	// intArray_t* copy = intArray_copy( arr1Ptr ); // COPY

	// printf("%d\n", copy->data[5]);


	// intArray_print( copy );  // PRINT COPY

// unsigned int* index = malloc(sizeof(int) * 1);
//intArrayResult_t value = intArray_find(arr1Ptr, 30, index);
//printf("%u\n", value);

char* file = malloc(sizeof(char)*8);
*file = 'b';

intArray_write_to_json( arr1Ptr, file);

intArray_t* arr2Ptr = intArray_load_from_json( file );

intArray_print(arr2Ptr); // PRINT




	return 0;

}
