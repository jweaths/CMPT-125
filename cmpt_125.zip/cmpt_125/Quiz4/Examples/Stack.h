/*
 * Stack.h
 *
 * Description: Implementation of a SHSL-based Stack of char with push/pop ...
 * Class Invariant: ... in a LIFO order.
 *
 * Author:
 * Date:
 */

#pragma once

class Stack {

  private:

    // Description:  Nodes for a singly-linked list.
    class StackNode {
      public:
        char data;
        StackNode * next;
      };

    // Description:  head = ptr to the first StackNode (NULL if empty)
    StackNode * head;

  public:

    // Description: Constructor
    // Postcondition: Stack is empty.
    Stack();

    // Description: Destructor
    // Postcondition: All nodes are deleted.
    ~Stack();

    // Description: Inserts "newElement" at the top of the Stack.
    // Postcondition: "newElement" is the new topmost element; other elements unchanged.
    void push(char newElement);

    // Description: Removes and returns element at the top of the Stack.
    // Precondition: Stack non empty.
    // Postcondition: Topmost element is removed and returned;
    //                other elements unchanged.
    char pop();

    // Description: Returns the topmost element of the stack.
    // Precondition: Stack non empty.
    // Postcondition: Elements unchanged (const).
    char peek() const;

    // Description: Returns true if and only if Stack is empty.
    // Postcondition: Elements unchanged (const).
    bool isEmpty() const;
};
