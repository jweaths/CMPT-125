/*
 * Node.cpp
 *
 * Class Definition: Node of a singly linked list
 *                   in which the data is of Grade data type.
 *
 * Created on:
 * Author:
 */

#include <cstdio>    // Needed for NULL
#include "Grade.h"
#include "Node.h"

using namespace std;


Node::Node()
{
	next = NULL;
}

Node::Node(Grade theData)
{
	data = theData;
	next = NULL;
}

Node::Node(Grade theData, Node* theNextNode)
{
	data = theData;
	next = theNextNode;

}

// end Node.cpp
