/*
 * Filename: stats.c
 *
 * Description: Reads floating point values from stdin until EOF is entered.
 *				input range is [-100,000... + 100,000] inclusive.
 *				output 2 decimal
 *				no arrays used
 *				assumed user is well-behaved
 *										
 *										The program outputs:	
 *										smalest value entered by user.
 *										largest values entered by the user.
 *										the arithmetic mean of all the values entered by user.
 *
 *
 * Author: JW
 * Date: May 30 2022
 */
 
 #include <stdio.h>
 
 int result = 0;
 const float MINIMUM = -100000.00;
 const float MAXIMUM = 100000.00;
 float number = 0.00;
 float minNumber = 0.00;
 float maxNumber = 0.00;
 float meanNumber = 0.00;
 float sumOfNums = 0.00;
 int count = 0;
 const int STEP = 1;
 
 
 int main( void ) 
	 
	 {
	 
	 printf("Please, enter a number between %0.2f and %0.2f: ", MINIMUM, MAXIMUM);
	 
	 while ( (result = scanf("%f", &number)) == 1 )
	 	
	 	{
	 	
	 	if (number > MINIMUM && number < MAXIMUM)
	 	
	 		{
	 	
	 	
		 	if (number <= minNumber) 
		 		
		 		{
		 		
		 		minNumber = number;
		 		
		 		}
		 	
		 	if (number >= maxNumber) 
		 		
		 		{
		 		
		 		maxNumber = number;
		 	
		 		}
		 	
		 	sumOfNums = sumOfNums + number;
	 		count = count + STEP;
		 	
		 	}
		 	
		 else
		 		
		 	{
		 		
		 	printf("%f is invalid!\n", number);
		 	
		 	}
	 
	 	printf("Please, enter a number between %0.2f and %0.2f: ", MINIMUM, MAXIMUM);
	 	
	 	} 
	 	
	 meanNumber = sumOfNums / count;
	 
	 printf("\nMin: %0.2f, max: %0.2f, mean: %0.2f\n", minNumber, maxNumber, meanNumber);
	 	
	 return 0;
	 
	 }
	 
	 
